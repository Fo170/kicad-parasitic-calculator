Icone du depot de plugins KiCad d'Olivier FOURNET.

icon.png : icone affichee par le gestionnaire de plugins et de contenus
           pour ce depot (64 x 64 px, PNG, fond transparent).
